# Raspberry Pi YouTube Music Docker Deployment & Shipping Guide

## 1. Project Overview
This guide covers setting up a lightweight, containerized **YouTube Music** client (`ytm.py`) on a Raspberry Pi using Docker. It features:
* **Stable ALSA/PipeWire audio routing** with zero deadlocks.
* **Persistent volume memory** (defaulting to 35% on initial startup and recalling user preferences).
* **GUI-based audio output device switching** mirroring the Raspberry Pi desktop speaker menu.
* Local song downloading via `yt-dlp` and playlist management.

---

## 2. Project File Structure
Create a working directory on your Raspberry Pi and create three files inside it:

```text
ytm-docker/
├── Dockerfile
├── docker-compose.yml
└── ytm.py
```

---

## 3. Required Configuration Files

### `Dockerfile`
```dockerfile
FROM python:3.11-slim

RUN apt-get update && apt-get install -y --no-install-recommends \
    mpv \
    ffmpeg \
    nodejs \
    alsa-utils \
    procps \
    && rm -rf /var/lib/apt/lists/*

RUN pip install --no-cache-dir --upgrade pip flask ytmusicapi yt-dlp

WORKDIR /app
COPY ytm.py /app/ytm.py

EXPOSE 8001

ENV YTM_PORT=8001 \
    YTM_DIR=/app/YTMusic

CMD ["python3", "ytm.py"]
```

### `docker-compose.yml`
```yaml
services:
  yt-music:
    build: .
    container_name: ytm-pi
    restart: unless-stopped
    ports:
      - "8001:8001"
    volumes:
      - ./YTMusic:/app/YTMusic
    devices:
      - /dev/snd:/dev/snd
    group_add:
      - audio
    environment:
      - YTM_PORT=8001
      - YTM_DIR=/app/YTMusic
      - MPV_AUDIO_DEVICE=alsa/default
```

---

## 4. Fresh Installation Guide (Raspberry Pi)

1. **Install Docker & Docker Compose** (if not already installed):
   ```bash
   curl -sSL https://get.docker.com | sh
   sudo usermod -aG docker $USER
   newgrp docker
   ```
2. **Navigate to your project folder**:
   ```bash
   cd ~/ytm-docker
   ```
3. **Build and launch the container**:
   ```bash
   docker compose up --build -d
   ```
4. **Access the App**: Open your phone or computer browser and navigate to:
   `http://<your-pi-ip>:8001`

---

## 5. Shipping & Running the Image on Other Machines

If you want to package your built container image and deploy it to another machine without rebuilding from source:

### Method: Exporting & Importing via Tar Archive (Offline Transfer)

1. **Build and package the image** into a `.tar` archive:
   ```bash
   docker compose build
   docker save -o ytm-pi-image.tar ytm-docker-yt-music:latest
   ```
2. **Transfer the archive** to your target machine using `scp` or a USB drive:
   ```bash
   scp ytm-pi-image.tar user@target-machine-ip:~/ytm-docker/
   ```
3. **On the target machine**, load the image into Docker:
   ```bash
   docker load -i ytm-pi-image.tar
   ```
4. Ensure your target machine has the corresponding `docker-compose.yml` and `ytm.py` files in place, then spin up the container instantly:
   ```bash
   docker compose up -d
   ```